package edu.dhbw.andar;

public class CameraStatus {
	protected boolean previewing  = false;
}
